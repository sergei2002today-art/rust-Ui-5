package com.rustui;

import java.util.ArrayList;
import java.util.List;
import net.minecraft.client.OptionInstance;
import net.minecraft.client.Options;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.AbstractWidget;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.client.gui.screens.options.OptionsScreen;
import net.minecraft.network.chat.Component;
import net.minecraft.sounds.SoundSource;

/** Rust-style settings: red category column + option rows. Uses the game's own option widgets. */
public class RustOptionsScreen extends RustMenuScreen {
    private static final String[] CATS = {"Графика", "Звук", "Управление", "Интерфейс", "Эффекты", "Все настройки"};
    private int category = 0;
    private final List<AbstractWidget> rows = new ArrayList<>();
    private final List<RustCatButton> cats = new ArrayList<>();

    public RustOptionsScreen(Screen parent) {
        super(Component.literal("Настройки"), parent, true, 3);
    }

    @Override
    protected void init() {
        addMainButtons();
        rows.clear();
        cats.clear();
        int x = colX0(), w = colX1() - colX0();
        int y = (int) (height * 0.36);
        for (int i = 0; i < CATS.length; i++) {
            final int idx = i;
            RustCatButton c = new RustCatButton(x, y + i * 20, w, 18, Component.literal(CATS[i]), b -> {
                RustTheme.playClick();
                category = idx;
                for (int k = 0; k < cats.size(); k++) cats.get(k).selected = (k == category);
                buildRows();
            });
            c.selected = (i == category);
            cats.add(c);
            addRenderableWidget(c);
        }
        buildRows();
    }

    private void buildRows() {
        for (AbstractWidget w : rows) removeWidget(w);
        rows.clear();
        Options o = minecraft.options;
        List<OptionInstance<?>> list = new ArrayList<>();
        switch (category) {
            case 0 -> {
                list.add(o.renderDistance());
                list.add(o.simulationDistance());
                list.add(o.framerateLimit());
                list.add(o.enableVsync());
                list.add(o.entityDistanceScaling());
                list.add(o.biomeBlendRadius());
                list.add(o.fov());
            }
            case 1 -> {
                list.add(o.getSoundSourceOptionInstance(SoundSource.MASTER));
                list.add(o.getSoundSourceOptionInstance(SoundSource.MUSIC));
                list.add(o.getSoundSourceOptionInstance(SoundSource.RECORDS));
                list.add(o.getSoundSourceOptionInstance(SoundSource.WEATHER));
                list.add(o.getSoundSourceOptionInstance(SoundSource.BLOCKS));
                list.add(o.getSoundSourceOptionInstance(SoundSource.HOSTILE));
                list.add(o.getSoundSourceOptionInstance(SoundSource.NEUTRAL));
                list.add(o.getSoundSourceOptionInstance(SoundSource.PLAYERS));
            }
            case 2 -> {
                list.add(o.sensitivity());
                list.add(o.autoJump());
                list.add(o.rawMouseInput());
            }
            case 3 -> {
                list.add(o.guiScale());
                list.add(o.chatOpacity());
                list.add(o.chatScale());
                list.add(o.textBackgroundOpacity());
                list.add(o.showSubtitles());
            }
            case 4 -> {
                list.add(o.particles());
                list.add(o.bobView());
                list.add(o.screenEffectScale());
                list.add(o.fovEffectScale());
                list.add(o.darknessEffectScale());
                list.add(o.damageTiltStrength());
                list.add(o.gamma());
            }
            default -> { }
        }
        int x = contentX();
        int w = Math.max(150, Math.min(300, width - x - 36));
        int y = 64;
        for (OptionInstance<?> opt : list) {
            AbstractWidget wd = opt.createButton(o);
            wd.setX(x);
            wd.setY(y);
            wd.setWidth(w);
            addRenderableWidget(wd);
            rows.add(wd);
            y += 22;
        }
        if (category == 5) {
            RustButton all = new RustButton(x, y, w, 20, Component.literal("Открыть все настройки Minecraft"), b -> {
                RustTheme.playClick();
                minecraft.setScreen(new OptionsScreen(this, minecraft.options));
            });
            addRenderableWidget(all);
            rows.add(all);
        }
    }

    @Override
    protected void renderContent(GuiGraphics g, int mouseX, int mouseY, long el) {
        g.fill(colX0(), 0, colX1(), height, RustTheme.a(0xCD412B, 0.72f));
        g.drawString(font, RustTheme.bold(CATS[category]), contentX(), 40, RustTheme.WHITE);
        g.fill(contentX(), 52, contentX() + 40, 54, RustTheme.RED);
    }
}
